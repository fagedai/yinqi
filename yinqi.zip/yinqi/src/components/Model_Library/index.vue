<script setup>

import Model_Library_body from './components/content.vue'

</script>

<template>
    <Model_Library_body></Model_Library_body>
</template>