<script setup>

import Service_body from './components/content.vue'


</script>

<template>
    
    <Service_body></Service_body>
    
</template>