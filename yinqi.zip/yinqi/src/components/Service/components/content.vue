<script steup>


</script>

<template>
    
    <div class="service mt-100">
            <div class="container">
                <div class="section-header">
                    <h2>Services</h2>
                    <p>
                        创意产品设计与生产是印奇科技当前的核心业务。印奇科技当前主要设计、生产“小比例模型”“创意潮玩”套件和成品，现已自主开发超30种产品；由于产品品质优良、价格合理，能提升许多玩家的制作和收藏体验，印奇科技正收获越来越多客户的认可。
                    </p>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-desktop"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">上传模型</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-laptop"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">Web Development</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-tablet-portrait"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">App Design</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-phone-portrait"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">App Development</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-desktop"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">Web Design</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-laptop"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">Web Development</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-tablet-portrait"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">App Design</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="service-item">
                            <div class="service-icon">
                                <i class="ion-ios-phone-portrait"></i>
                            </div>
                            <div class="service-detail">
                                <h4><a href="">App Development</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



</template>