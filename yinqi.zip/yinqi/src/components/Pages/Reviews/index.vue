<script setup>
</script>

<template>
  <div class="testimonials mt-100">
    <div class="container">
      <div class="section-header">
        <h2>Reviews</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
          ac lacus eget nunc imperdiet
        </p>
      </div>

      <div class="owl-carousel testimonials-carousel">
        <div class="testimonial-item row align-items-center">
          <div class="testimonial-img">
            <img src="/src/assets/testimonial-1.jpg" alt="Testimonial image" />
          </div>
          <div class="testimonial-text">
            <h3>Anna M. Brzezinski</h3>
            <h4>businesswoman</h4>
            <p>
              Lorem ipsum dolor sit amet consectetur adipiscing elit. Maecenas
              dictum vel
            </p>
          </div>
        </div>
        <div class="testimonial-item row align-items-center">
          <div class="testimonial-img">
            <img src="/src/assets/testimonial-2.jpg" alt="Testimonial image" />
          </div>
          <div class="testimonial-text">
            <h3>Shirley H. Lee</h3>
            <h4>businesswoman</h4>
            <p>
              Lorem ipsum dolor sit amet consectetur adipiscing elit. Maecenas
              dictum vel
            </p>
          </div>
        </div>
        <div class="testimonial-item row align-items-center">
          <div class="testimonial-img">
            <img src="/src/assets/testimonial-3.jpg" alt="Testimonial image" />
          </div>
          <div class="testimonial-text">
            <h3>Kerry E. Thomas</h3>
            <h4>businesswoman</h4>
            <p>
              Lorem ipsum dolor sit amet consectetur adipiscing elit. Maecenas
              dictum vel
            </p>
          </div>
        </div>
        <div class="testimonial-item row align-items-center">
          <div class="testimonial-img">
            <img src="/src/assets/testimonial-4.jpg" alt="Testimonial image" />
          </div>
          <div class="testimonial-text">
            <h3>Kerry E. Thomas</h3>
            <h4>businesswoman</h4>
            <p>
              Lorem ipsum dolor sit amet consectetur adipiscing elit. Maecenas
              dictum vel
            </p>
          </div>
        </div>
        <div class="testimonial-item row align-items-center">
          <div class="testimonial-img">
            <img src="/src/assets/testimonial-5.jpg" alt="Testimonial image" />
          </div>
          <div class="testimonial-text">
            <h3>Kerry E. Thomas</h3>
            <h4>businesswoman</h4>
            <p>
              Lorem ipsum dolor sit amet consectetur adipiscing elit. Maecenas
              dictum vel
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>