<script setup>
</script>

<template>
  <div class="skills mt-100">
    <div class="container">
      <div class="section-header">
        <h2>Our Skills</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
          ac lacus eget nunc imperdiet
        </p>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="skill-item">
            <h3>Front End Skills</h3>
            <div class="skill-name">
              <p>HTML</p>
              <p>85%</p>
            </div>
            <div class="progress">
              <div
                class="progress-bar"
                role="progressbar"
                aria-valuenow="85"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>

            <div class="skill-name">
              <p>CSS</p>
              <p>95%</p>
            </div>
            <div class="progress">
              <div
                class="progress-bar"
                role="progressbar"
                aria-valuenow="95"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>

            <div class="skill-name">
              <p>jQuery</p>
              <p>80%</p>
            </div>
            <div class="progress">
              <div
                class="progress-bar"
                role="progressbar"
                aria-valuenow="80"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="skill-item">
            <h3>Back End Skills</h3>
            <div class="skill-name">
              <p>PHP</p>
              <p>90%</p>
            </div>
            <div class="progress">
              <div
                class="progress-bar"
                role="progressbar"
                aria-valuenow="90"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>

            <div class="skill-name">
              <p>Laravel</p>
              <p>85%</p>
            </div>
            <div class="progress">
              <div
                class="progress-bar"
                role="progressbar"
                aria-valuenow="85"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>

            <div class="skill-name">
              <p>MySQL</p>
              <p>95%</p>
            </div>
            <div class="progress">
              <div
                class="progress-bar"
                role="progressbar"
                aria-valuenow="95"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>