<script setup>

</script>
<template>
  <div class="clients mt-100">
    <div class="container">
      <div class="section-header">
        <h2>Our Clients</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
          ac lacus eget nunc imperdiet
        </p>
      </div>

      <div class="owl-carousel clients-carousel">
        <img src="/src/assets/client-1.jpg" alt="Client Logo" />
        <img src="/src/assets/client-2.jpg" alt="Client Logo" />
        <img src="/src/assets/client-3.jpg" alt="Client Logo" />
        <img src="/src/assets/client-4.jpg" alt="Client Logo" />
        <img src="/src/assets/client-5.jpg" alt="Client Logo" />
        <img src="/src/assets/client-6.jpg" alt="Client Logo" />
        <img src="/src/assets/client-7.jpg" alt="Client Logo" />
        <img src="/src/assets/client-8.jpg" alt="Client Logo" />
      </div>
    </div>
  </div>
</template>