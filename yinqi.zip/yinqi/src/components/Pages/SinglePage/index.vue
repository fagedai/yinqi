<script setup>
</script>
<template>
  <div class="single mt-100">
    <div class="container">
      <div class="section-header">
        <h2>Single Page</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
          ac lacus eget nunc imperdiet
        </p>
      </div>

      <div class="row align-items-center">
        <div class="col-md-12">
          <div class="single-img">
            <img src="/src/assets/single.jpg" alt="" class="img-fluid" />
          </div>
          <div class="single-content">
            <h2>Lorem ipsum dolor sit amet</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam
              commodo lacus vel turpis dapibus lobortis. Nullam nibh magna,
              suscipit eget porta nec, porttitor in augue. Donec iaculis tellus
              justo, convallis fringilla ligula iaculis vel. Etiam at lacus
              laoreet elit posuere malesuada. Vivamus lacus odio, aliquet sed
              mollis non, rutrum lacinia lacus. Praesent non rhoncus dolor. Orci
              varius natoque penatibus et magnis dis parturient montes, nascetur
              ridiculus mus. Curabitur tincidunt lectus velit, vel condimentum
              diam volutpat sit amet. Nam ac varius urna, at cursus est. Donec
              sit amet ante elementum, dapibus justo ut, tincidunt quam. Aenean
              posuere nisi eu blandit lacinia.
            </p>
            <h2>Sed ornare sapien nec hendrerit suscipit</h2>
            <p>
              Sed ornare sapien nec hendrerit suscipit. Quisque non nunc justo.
              Curabitur tempor dapibus ullamcorper. Cras sit amet metus sed
              lectus imperdiet convallis. Morbi fermentum diam vel auctor
              convallis. In eu viverra justo, eget placerat magna. Maecenas odio
              nulla, efficitur vitae venenatis vel, malesuada et ipsum. Fusce et
              ullamcorper ligula, nec commodo lectus. Ut sed risus sodales
              tortor scelerisque egestas. Interdum et malesuada fames ac ante
              ipsum primis in faucibus. Nam nulla turpis, tempor ac lorem id,
              rhoncus lobortis ipsum. Donec faucibus tortor sit amet lacus
              consequat elementum.
            </p>
            <p>
              Fusce sollicitudin dignissim elementum. Donec sed erat sit amet
              purus egestas faucibus. Aliquam erat volutpat. Maecenas eleifend
              elementum est, congue facilisis massa. Proin eu fringilla mauris.
              Mauris vulputate tempus lectus eu consectetur. Vestibulum eget
              efficitur eros, quis finibus nisl. In suscipit erat nec sem
              sollicitudin mollis. In hac habitasse platea dictumst. Aliquam
              convallis tincidunt volutpat. Suspendisse efficitur justo enim, in
              sagittis lorem suscipit vitae. Maecenas a molestie risus, vitae
              tempus est. Maecenas sem tellus, varius ac viverra id, tristique
              vitae libero. Aliquam ornare augue ut diam porta consectetur.
              Vivamus varius rhoncus diam, nec condimentum est pulvinar in.
              Vestibulum non tincidunt ante.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>