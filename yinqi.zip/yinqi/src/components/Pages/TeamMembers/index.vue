<script setup>
</script>
<template>
  <div class="team mt-100">
    <div class="container">
      <div class="section-header">
        <h2>Meet our team</h2>
        <p>
          我们的3D打印团队由一群对3D技术充满热情的专业人士组成。团队成员拥有丰富的设计和工程经验，以及对材料科学和制造工艺的深入了解。我们团队注重合作与创新，致力于为客户提供最优质的定制化3D打印解决方案。
        </p>
      </div>

      <div class="row">
        <div class="col-lg-3 col-sm-6 team-item">
          <div class="team-img">
            <img
              src="/src/assets/lnnTeam.jpg"
              class="img-fluid"
              alt="Team Member"
            />
            <div class="team-social">
              <a href="#"><i class="ion-logo-twitter"></i></a>
              <a href="#"><i class="ion-logo-facebook"></i></a>
              <a href="#"><i class="ion-logo-linkedin"></i></a>
              <a href="#"><i class="ion-logo-instagram"></i></a>
            </div>
          </div>
          <div class="team-info">
            <h3>李娜娜</h3>
            <p>副教授</p>
          </div>
        </div>

        <div class="col-lg-3 col-sm-6 team-item">
          <div class="team-img">
            <img
              src="/src/assets/fudaoyuan.jpg"
              class="img-fluid"
              alt="Team Member"
            />
            <div class="team-social">
              <a href="#"><i class="ion-logo-twitter"></i></a>
              <a href="#"><i class="ion-logo-facebook"></i></a>
              <a href="#"><i class="ion-logo-linkedin"></i></a>
              <a href="#"><i class="ion-logo-instagram"></i></a>
            </div>
          </div>
          <div class="team-info">
            <h3>何彦北</h3>
            <p>辅导员</p>
          </div>
        </div>

        <div class="col-lg-3 col-sm-6 team-item">
          <div class="team-img">
            <img
              src="/src/assets/team-3.jpg"
              class="img-fluid"
              alt="Team Member"
            />
            <div class="team-social">
              <a href="#"><i class="ion-logo-twitter"></i></a>
              <a href="#"><i class="ion-logo-facebook"></i></a>
              <a href="#"><i class="ion-logo-linkedin"></i></a>
              <a href="#"><i class="ion-logo-instagram"></i></a>
            </div>
          </div>
          <div class="team-info">
            <h3>Dana A. Thomas</h3>
            <p>Apps Developer</p>
          </div>
        </div>

        <div class="col-lg-3 col-sm-6 team-item">
          <div class="team-img">
            <img
              src="/src/assets/team-4.jpg"
              class="img-fluid"
              alt="Team Member"
            />
            <div class="team-social">
              <a href="#"><i class="ion-logo-twitter"></i></a>
              <a href="#"><i class="ion-logo-facebook"></i></a>
              <a href="#"><i class="ion-logo-linkedin"></i></a>
              <a href="#"><i class="ion-logo-instagram"></i></a>
            </div>
          </div>
          <div class="team-info">
            <h3>Ava M. Proctor</h3>
            <p>Apps Developer</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>