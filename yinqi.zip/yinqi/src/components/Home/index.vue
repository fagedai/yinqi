<script setup>
import Nav from '../Nav/index.vue'
import Floor from '../Floor/index.vue'
</script>

<template>
    <Nav></Nav>
    <RouterView />
    <Floor></Floor>
</template>