<script setup>

import Pricing from "./components/content.vue";

</script>

<template>

  <Pricing />

</template>
