<script setup>

</script>
<template>
  <div class="pricing mt-100">
    <div class="container">
      <div class="section-header">
        <h2>Our Pricing</h2>
        <p>
          Pellentesque habitant morbi tristique senectus et netus et malesuada
          fames ac turpis egestas
        </p>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="price-content">
            <div class="price-plan">
              <i class="ion-md-home"></i>
              <p class="price-title">Silver</p>
              <h2 class="price-amount">
                <span>$</span>9<span>.99</span><span> / m</span>
              </h2>
            </div>
            <ul class="price-details">
              <li>
                <i class="ion-md-checkmark"></i><strong>HTML5</strong> and
                <strong>CSS3</strong>
              </li>
              <li>
                <i class="ion-md-checkmark"></i><strong>Bootstrap 4</strong>
              </li>
              <li>
                <i class="ion-md-checkmark"></i
                ><strong>Well-commented</strong> code
              </li>
              <li>
                <i class="ion-md-close"></i><strong>IonIcons</strong> integrated
              </li>
              <li>
                <i class="ion-md-close"></i>Free
                <strong>Google Font</strong> integrated
              </li>
              <li>
                <i class="ion-md-close"></i><strong>Responsive</strong> design
              </li>
            </ul>
            s
            <a href="#" class="btn mian-btn price-btn">Buy Now</a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="price-content features-price">
            <div class="price-plan">
              <i class="ion-md-star"></i>
              <p class="price-title">Gold</p>
              <h2 class="price-amount">
                <span>$</span>19<span>.99</span><span> / m</span>
              </h2>
            </div>
            <ul class="price-details">
              <li>
                <i class="ion-md-checkmark"></i><strong>HTML5</strong> and
                <strong>CSS3</strong>
              </li>
              <li>
                <i class="ion-md-checkmark"></i><strong>Bootstrap 4</strong>
              </li>
              <li>
                <i class="ion-md-checkmark"></i
                ><strong>Well-commented</strong> code
              </li>
              <li>
                <i class="ion-md-checkmark"></i
                ><strong>IonIcons</strong> integrated
              </li>
              <li>
                <i class="ion-md-checkmark"></i>Free
                <strong>Google Font</strong> integrated
              </li>
              <li>
                <i class="ion-md-close"></i><strong>Responsive</strong> design
              </li>
            </ul>
            <a href="#" class="btn mian-btn price-btn features-price-btn"
              >Buy Now</a
            >
          </div>
        </div>
        <div class="col-md-4">
          <div class="price-content">
            <div class="price-plan">
              <i class="ion-md-gift"></i>
              <p class="price-title">Platinum</p>
              <h2 class="price-amount">
                <span>$</span>29<span>.99</span><span> / m</span>
              </h2>
            </div>
            <ul class="price-details">
              <li>
                <i class="ion-md-checkmark"></i><strong>HTML5</strong> and
                <strong>CSS3</strong>
              </li>
              <li>
                <i class="ion-md-checkmark"></i><strong>Bootstrap 4</strong>
              </li>
              <li>
                <i class="ion-md-checkmark"></i
                ><strong>Well-commented</strong> code
              </li>
              <li>
                <i class="ion-md-checkmark"></i
                ><strong>IonIcons</strong> integrated
              </li>
              <li>
                <i class="ion-md-checkmark"></i>Free
                <strong>Google Font</strong> integrated
              </li>
              <li>
                <i class="ion-md-checkmark"></i
                ><strong>Responsive</strong> design
              </li>
            </ul>
            <a href="#" class="btn mian-btn price-btn">Buy Now</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>