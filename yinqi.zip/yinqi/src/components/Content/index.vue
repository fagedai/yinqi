<script setup>
import Banner from './components/Banner.vue'
import About from '../About/index.vue'
import Service from '../Service/index.vue'
import Model_Library from '../Model_Library/index.vue'
import Pricing from '../Pricing/index.vue'
// import Pages from '../Pages.vue'
import Skills from '../Pages/Skills/index.vue'
import SinglePage from '../Pages/SinglePage/index.vue'
import TeamMembers from '../Pages/TeamMembers/index.vue'


</script>

<template>
    <Banner></Banner>
    <About></About>
    <Service></Service>
    <Model_Library></Model_Library>
    <Pricing></Pricing>
    <!-- <Pages></Pages> -->
    <Skills></Skills>
    
  
    <SinglePage></SinglePage>
    <TeamMembers></TeamMembers>

</template>