<script>

</script>

<template>
    <div class="about mt-100">
        <div class="container">
            <div class="section-header animate__animated animate__fadeInUp">
                <h2>About Us</h2>
                <p>
                    深圳市印奇科技有限公司，创立于2023年5月，深植于“创意之都”深圳，扎根于新型应用型高校深圳技术大学，是主要面向深圳范围内各高校师生的3D打印、定制化建模设计、成品制作全流程服务提供商，根据客户的定制需求设计、生产或制作产品。
                </p>
            </div>

            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="about-img">
                        <img src="/src/assets/about.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="about-content">
                        <h2>Welcome to Our Site</h2>
                        <p>
                            印奇科技正与深圳技术大学3D打印社合作，双方共同致力于为校园师生提供一个便利性、个性化、高品质、共创性的3D打印云平台。这一产品在启用初期将主要服务校内师生及团体；随后，沂依科技将依托现有资源，助推其进入各大高校3D打印市场，力争成为全国高校商业化3D打印云平台的先行者和引领者。

                        </p>
                        <a class="btn" href="#">Read More</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="about-img">
                        <img src="/src/assets/about-story.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="about-content">
                        <h2>Our Story</h2>
                        <p>
                            一切始于大学校园里的一个想法。一群对科技和创新充满热情的大学生聚在一起，探讨如何利用3D打印来解决现实生活中的问题。经过无数个深夜的头脑风暴和艰苦的努力，他们决定将这个想法变成现实，于是我们的公司诞生了。

                            起初，我们只是在寝室里用自己的3D打印机进行实验，尝试打印各种不同的原型和样品。随着我们的技术和经验不断积累，我们开始制定商业计划，并向投资者展示我们的想法。通过不懈的努力和对技术的不断探索，我们最终获得了初步资金支持，正式成立了公司。

                            从那以后，我们不断扩大团队规模，招募了更多对技术和创新充满热情的人才。我们投入大量时间和精力，研发出更加先进和高效的3D打印技术，同时也不断开拓市场，寻找合适的合作伙伴和客户。

                            如今，我们的公司已经成长为一家在3D打印领域具有一定影响力的企业，我们致力于为客户提供高质量、个性化定制的3D打印产品和解决方案。我们始终秉承着初创时的激情和创造力，不断追求技术创新和服务卓越，在未来也会继续为客户创造更大的价值。
                        </p>
                        <a class="btn" href="#">Read More</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-img">
                        <img src="/src/assets/about-goal.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="about-content">
                        <h2>Our Goal</h2>
                        <p>
                            此外，公司还计划逐步扩大市场，与对航天军工、医疗、文创教育、汽车、艺术品等制造难度较高的产品有着较大生产需求的各类高校合作。这些领域对产品精度、材质和生产效率有着严格的要求，3D打印技术具有明显优势。通过与这些高校的合作，“YY造物”3D打印云平台将为各类复杂产品提供定制化、高效的生产解决方案，助力我国高端制造业的发展。
                        </p>
                        <a class="btn" href="#">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>