<script setup>
import Content from './components/content.vue'
</script>

<template>
    <Content></Content>
</template>