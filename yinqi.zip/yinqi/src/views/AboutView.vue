<script setup>
import About from '@/components/About/index.vue'
</script>

<template>
    <About></About>
</template>