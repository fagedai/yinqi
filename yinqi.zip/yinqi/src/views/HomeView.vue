<script setup>
import Home from '@/components/Home/index.vue'
</script>

<template>
    <Home></Home>
</template>